# Guía para construir el mapa en Roblox Studio

## Diseño general
Construye una isla natural con una aldea en el centro y caminos que conecten los puntos de interés.

```text
              [Mirador de montaña]
                       |
        [Bosque] -- [Cueva] -- [Cascada]
            \          |          /
             \      [Aldea] ------ [Río]
                      |
                 [Spawn inicial]
```

## Pasos
1. Abre Roblox Studio y crea una experiencia Baseplate.
2. En `Home > Terrain Editor`, usa `Generate` o las herramientas `Add`, `Draw`, `Sculpt` y `Paint` para crear una isla con colinas y un río.
3. Añade árboles, rocas, hierba y plantas. Usa assets confiables del Creator Store y revisa los scripts incluidos en modelos gratuitos.
4. Crea un punto de aparición con `SpawnLocation` cerca de la aldea.
5. Crea una carpeta `Coins` dentro de `Workspace`. Coloca varias piezas pequeñas amarillas con forma de moneda; pon `Anchored = true`, `CanCollide = false` y `CanTouch = true`.
6. Crea un modelo o pieza `Shopkeeper` en `Workspace`. Dentro de una pieza añade `ProximityPrompt`.
7. Para ambientación, añade casas de madera, faroles, bancos, señales y un puente sobre el río.
8. Prueba el juego con `Play`. Revisa la ventana `Output` para ver mensajes y errores.

## Sugerencias de escala
- Aldea: aproximadamente 250 x 250 studs.
- Bosque: área de 500 x 500 studs.
- Senderos: 12–20 studs de ancho.
- Monedas: distribuidas por caminos, cerca de miradores y alrededor de la aldea.

## Antes de publicar
- Comprueba colisiones, rendimiento y accesibilidad.
- Prueba en computadora y móvil.
- Evita modelos de terceros con scripts que no entiendas.
- Configura y prueba DataStore en una experiencia de prueba publicada.
