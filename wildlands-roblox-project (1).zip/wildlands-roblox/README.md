# Wildlands: Aventura Natural

Proyecto inicial de mundo abierto para Roblox Studio, escrito en Luau y organizado para sincronizarse con Rojo.

## Características incluidas
- Estadísticas del jugador: monedas.
- Recolección de monedas mediante `Touched`.
- Misión inicial: recoger 10 monedas.
- Comerciante con `ProximityPrompt` que vende una mejora de velocidad por 25 monedas.
- Guardado de monedas y progreso de misión con DataStore.
- Estructura lista para GitHub y Rojo.

## Requisitos
- Roblox Studio.
- Rojo (herramienta de sincronización de archivos con Roblox Studio).
- Una experiencia publicada para probar DataStore en un entorno de prueba.

## Estructura
```text
wildlands-roblox/
├── src/
│   ├── server/
│   │   ├── PlayerData.server.lua
│   │   ├── CoinService.server.lua
│   │   ├── QuestService.server.lua
│   │   └── ShopService.server.lua
│   └── shared/
│       └── GameConfig.lua
├── docs/
│   └── MAP_BUILD_GUIDE.md
├── default.project.json
├── .gitignore
└── README.md
```

## Cómo instalarlo
1. Descarga y descomprime el proyecto.
2. Instala Rojo y abre Roblox Studio.
3. Crea una experiencia nueva y guarda/publica una primera versión.
4. En Roblox Studio, crea estas carpetas en `Workspace`:
   - `Coins`: coloca dentro monedas (Part o MeshPart). Cada moneda debe tener `CanTouch = true`.
   - `Shopkeeper`: crea un Part o modelo para el comerciante. Dentro de una pieza del modelo agrega un `ProximityPrompt`.
5. En las propiedades de la experiencia de prueba, activa **Enable Studio Access to API Services** solo para probar DataStore en Studio. No lo actives en proyectos ajenos.
6. En una terminal, desde esta carpeta, ejecuta `rojo serve default.project.json`.
7. En Roblox Studio instala/abre el plugin de Rojo y conéctalo al servidor local. Sincroniza el proyecto.
8. Prueba con **Play**. Para comprobar guardado, sal y vuelve a entrar a una experiencia publicada de prueba.

## Reglas importantes
- La lógica de monedas, compras y guardado está en el servidor; no confíes en valores enviados por el cliente.
- DataStore puede fallar temporalmente. Los scripts usan `pcall` para evitar que un fallo de guardado cierre el juego.
- Los datos persistentes solo funcionan correctamente al probar en una experiencia publicada con las opciones adecuadas.
- El proyecto es una base inicial: todavía debes construir el terreno, colocar monedas y decorar el mundo.

## Primer objetivo de juego
Explora la isla, recoge 10 monedas para completar la misión inicial y visita al comerciante para comprar una mejora de velocidad por 25 monedas.
