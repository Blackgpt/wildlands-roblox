-- Las monedas deben estar dentro de Workspace/Coins.
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local coinFolder = Workspace:WaitForChild("Coins")

local collected = {}

local function setupCoin(coin)
    if not coin:IsA("BasePart") then
        return
    end

    coin.CanTouch = true
    coin.Anchored = true

    coin.Touched:Connect(function(hit)
        local character = hit:FindFirstAncestorOfClass("Model")
        if not character then return end

        local player = Players:GetPlayerFromCharacter(character)
        if not player or collected[coin] then return end

        local stats = player:FindFirstChild("leaderstats")
        local coins = stats and stats:FindFirstChild("Coins")
        if not coins then return end

        collected[coin] = true
        coins.Value += Config.CoinValue
        player:SetAttribute("QuestCoins", (player:GetAttribute("QuestCoins") or 0) + 1)

        coin.Transparency = 1
        coin.CanTouch = false
        coin.CanCollide = false

        task.delay(12, function()
            if coin and coin.Parent then
                coin.Transparency = 0
                coin.CanTouch = true
                coin.CanCollide = true
                collected[coin] = nil
            end
        end)
    end)
end

for _, coin in ipairs(coinFolder:GetChildren()) do
    setupCoin(coin)
end
coinFolder.ChildAdded:Connect(setupCoin)
