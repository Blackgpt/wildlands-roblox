-- Crea leaderstats y guarda monedas/progreso de misión.
local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local Store = DataStoreService:GetDataStore("WildlandsPlayerData_v1")

local function makeLeaderstats(player, coins)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    local coinValue = Instance.new("IntValue")
    coinValue.Name = "Coins"
    coinValue.Value = math.max(0, tonumber(coins) or Config.StartingCoins)
    coinValue.Parent = leaderstats
end

local function loadPlayer(player)
    local key = "player_" .. player.UserId
    local data

    local ok, result = pcall(function()
        return Store:GetAsync(key)
    end)

    if ok and type(result) == "table" then
        data = result
    else
        data = { Coins = Config.StartingCoins, QuestCoins = 0 }
        if not ok then
            warn("[Wildlands] No se pudieron cargar datos para " .. player.Name)
        end
    end

    makeLeaderstats(player, data.Coins)
    player:SetAttribute("QuestCoins", math.max(0, tonumber(data.QuestCoins) or 0))
    player:SetAttribute("QuestClaimed", data.QuestClaimed == true)
    player:SetAttribute("SpeedBoostOwned", false)
end

local function savePlayer(player)
    local stats = player:FindFirstChild("leaderstats")
    local coins = stats and stats:FindFirstChild("Coins")
    local data = {
        Coins = coins and coins.Value or Config.StartingCoins,
        QuestCoins = player:GetAttribute("QuestCoins") or 0,
        QuestClaimed = player:GetAttribute("QuestClaimed") == true,
    }

    local ok, err = pcall(function()
        Store:UpdateAsync("player_" .. player.UserId, function()
            return data
        end)
    end)

    if not ok then
        warn("[Wildlands] Error guardando a " .. player.Name .. ": " .. tostring(err))
    end
end

Players.PlayerAdded:Connect(loadPlayer)
Players.PlayerRemoving:Connect(savePlayer)

game:BindToClose(function()
    for _, player in ipairs(Players:GetPlayers()) do
        savePlayer(player)
    end
end)
