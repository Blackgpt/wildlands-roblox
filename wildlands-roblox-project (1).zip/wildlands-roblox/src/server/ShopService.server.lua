-- Añade un ProximityPrompt dentro de Workspace/Shopkeeper o una de sus piezas.
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local shopkeeper = Workspace:WaitForChild("Shopkeeper")

local function findPrompt(container)
    for _, item in ipairs(container:GetDescendants()) do
        if item:IsA("ProximityPrompt") then
            return item
        end
    end
    return nil
end

local prompt = findPrompt(shopkeeper)
if not prompt then
    warn("[Wildlands] Añade un ProximityPrompt dentro de Workspace/Shopkeeper.")
    return
end

prompt.ActionText = "Comprar mejora"
prompt.ObjectText = Config.ShopItemName
prompt.HoldDuration = 0.5
prompt.MaxActivationDistance = 10

prompt.Triggered:Connect(function(player)
    if player:GetAttribute("SpeedBoostOwned") then
        print("[Tienda] Ya tienes la mejora de velocidad.")
        return
    end

    local stats = player:FindFirstChild("leaderstats")
    local coins = stats and stats:FindFirstChild("Coins")
    if not coins then return end

    if coins.Value < Config.ShopItemCost then
        print("[Tienda] Necesitas " .. Config.ShopItemCost .. " monedas para comprar la mejora.")
        return
    end

    coins.Value -= Config.ShopItemCost
    player:SetAttribute("SpeedBoostOwned", true)

    local function applyBoost(character)
        local humanoid = character:FindFirstChildOfClass("Humanoid")
        if humanoid then
            humanoid.WalkSpeed = Config.BoostWalkSpeed
        end
    end

    if player.Character then
        applyBoost(player.Character)
    end
    player.CharacterAdded:Connect(applyBoost)

    print("[Tienda] " .. player.Name .. " compró la mejora de velocidad.")
end)
