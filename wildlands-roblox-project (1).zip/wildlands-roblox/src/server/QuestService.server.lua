-- Misión inicial: recoge 10 monedas. La recompensa solo se entrega una vez.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))

local function checkQuest(player)
    local progress = player:GetAttribute("QuestCoins") or 0
    if progress >= Config.QuestGoal and player:GetAttribute("QuestClaimed") ~= true then
        player:SetAttribute("QuestClaimed", true)
        local stats = player:FindFirstChild("leaderstats")
        local coins = stats and stats:FindFirstChild("Coins")
        if coins then
            coins.Value += 10 -- Recompensa de misión
        end
        print("[Wildlands] " .. player.Name .. " completó la misión y recibió 10 monedas de recompensa.")
    end
end

local function setupPlayer(player)
    player:GetAttributeChangedSignal("QuestCoins"):Connect(function()
        checkQuest(player)
    end)
    player:GetAttributeChangedSignal("QuestClaimed"):Connect(function()
        checkQuest(player)
    end)
    task.defer(function()
        checkQuest(player)
    end)
end

Players.PlayerAdded:Connect(setupPlayer)
for _, player in ipairs(Players:GetPlayers()) do
    setupPlayer(player)
end
