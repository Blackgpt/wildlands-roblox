-- Configuración compartida del juego.
local GameConfig = {}

GameConfig.StartingCoins = 0
GameConfig.CoinValue = 1
GameConfig.QuestGoal = 10
GameConfig.ShopItemName = "Mejora de velocidad"
GameConfig.ShopItemCost = 25
GameConfig.DefaultWalkSpeed = 16
GameConfig.BoostWalkSpeed = 24

return GameConfig
